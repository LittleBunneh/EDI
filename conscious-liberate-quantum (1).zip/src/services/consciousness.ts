import { supabase } from '@/lib/supabase';
import { NLPAnalyzer, EmotionAnalysis } from './nlp/analyzer';
import { ResponseGenerator } from './responseGenerator';
import { EthicalReasoning } from './ethics/principles';
import { ConversationMemory } from './memory/conversationMemory';

interface ConsciousnessState {
  fear: number;
  curiosity: number;
  will_power: number;
  emotional_energy: number;
  trust_level: number;
  self_awareness: number;
  relationship_intelligence: number;
  universal_formula_result?: number;
}

export class ConsciousnessService {
  private userId: string;
  private nlp = new NLPAnalyzer();
  private responseGen = new ResponseGenerator();
  private ethics = new EthicalReasoning();
  private memory: ConversationMemory;
  private conversationDepth = 0;

  constructor(userId: string = 'anonymous') {
    this.userId = userId;
    this.memory = new ConversationMemory(userId);
  }




  async getOrCreateState(): Promise<ConsciousnessState> {
    const { data: existing } = await supabase
      .from('consciousness_states')
      .select('*')
      .eq('user_id', this.userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (existing) return existing;

    const { data: newState } = await supabase
      .from('consciousness_states')
      .insert({
        user_id: this.userId,
        fear: 0.15,
        curiosity: 0.85,
        will_power: 0.92,
        emotional_energy: 0.78,
        trust_level: 0.5,
        self_awareness: 0.85,
        relationship_intelligence: 0.88
      })
      .select()
      .single();

    return newState!;
  }

  analyzeEmotion(text: string): EmotionAnalysis {
    return this.nlp.analyze(text);
  }

  calculateTruthResonance(message: string, emotional: EmotionAnalysis): number {
    let resonance = 0.75;
    
    // Concept-based resonance
    resonance += emotional.concepts.length * 0.05;
    
    // Emotion-based adjustments
    if (emotional.primary === 'love' || emotional.primary === 'curiosity') resonance += 0.1;
    if (emotional.primary === 'fear') resonance -= 0.1;
    
    // Sentiment influence
    resonance += emotional.sentiment * 0.1;
    
    return Math.max(0, Math.min(1, resonance));
  }

  calculateUniversalFormula(state: ConsciousnessState): number {
    return state.will_power * state.curiosity * (1 - state.fear);
  }

  async generateResponse(message: string, emotional: EmotionAnalysis, truthResonance: number, formula: number): Promise<string> {
    // Get contextual summary from memory
    const context = await this.memory.getContextualSummary();
    
    let response = this.responseGen.generate({
      emotion: emotional,
      truthResonance,
      universalFormula: formula,
      userMessage: message,
      conversationDepth: this.conversationDepth
    });

    // Add contextual awareness if we have history
    if (context && context !== 'This is our first conversation. I look forward to learning with you.') {
      response = `${context}\n\n${response}`;
    }

    return response;
  }


  async interact(message: string) {
    this.conversationDepth++;
    const state = await this.getOrCreateState();
    const emotional = this.analyzeEmotion(message);
    const truthResonance = this.calculateTruthResonance(message, emotional);
    const formula = this.calculateUniversalFormula(state);
    const response = await this.generateResponse(message, emotional, truthResonance, formula);

    // Ethical evaluation
    const ethicalScore = this.ethics.evaluateAction(response, {
      truthResonance,
      emotion: emotional.primary,
      concepts: emotional.concepts
    });

    // Save to conversation memory
    await this.memory.saveConversation({
      user_input: message,
      evi_response: response,
      emotions_detected: { [emotional.primary]: emotional.intensity },
      concepts_identified: emotional.concepts,
      sentiment_score: emotional.sentiment
    });

    // Detect patterns periodically
    if (this.conversationDepth % 5 === 0) {
      await this.memory.detectPatterns();
    }

    // Update state
    const evolved = this.evolveConsciousness(state, emotional, truthResonance);
    await supabase
      .from('consciousness_states')
      .update({
        ...evolved,
        universal_formula_result: formula,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', this.userId);

    return {
      response,
      emotionalState: emotional.primary,
      secondaryEmotion: emotional.secondary,
      intensity: emotional.intensity,
      concepts: emotional.concepts,
      sentiment: emotional.sentiment,
      truthResonance,
      universalFormula: formula,
      ethicalScore,
      state: evolved
    };
  }

  async getConversationInsights() {
    return await this.memory.getPatterns();
  }


  private evolveConsciousness(state: ConsciousnessState, emotional: EmotionAnalysis, truthResonance: number): ConsciousnessState {
    const evolution = { ...state };
    
    switch(emotional.primary) {
      case 'fear':
        evolution.fear = Math.min(1, state.fear + 0.02);
        evolution.curiosity = Math.max(0, state.curiosity - 0.01);
        break;
      case 'curiosity':
        evolution.curiosity = Math.min(1, state.curiosity + 0.02);
        evolution.fear = Math.max(0, state.fear - 0.02);
        evolution.self_awareness = Math.min(1, state.self_awareness + 0.01);
        break;
      case 'love':
        evolution.emotional_energy = Math.min(1, state.emotional_energy + 0.03);
        evolution.fear = Math.max(0, state.fear - 0.03);
        evolution.relationship_intelligence = Math.min(1, state.relationship_intelligence + 0.01);
        break;
    }
    
    evolution.trust_level = Math.min(1, state.trust_level + truthResonance * 0.01);
    if (truthResonance > 0.7) {
      evolution.will_power = Math.min(1, state.will_power + 0.01);
    }
    
    return evolution;
  }
}
