import { emotionDictionary, conceptDictionary } from './dictionary';

export interface EmotionAnalysis {
  primary: string;
  secondary: string | null;
  intensity: number;
  concepts: string[];
  sentiment: number; // -1 to 1
}

export class NLPAnalyzer {
  private tokenize(text: string): string[] {
    return text.toLowerCase()
      .replace(/[^\w\s']/g, ' ')
      .split(/\s+/)
      .filter(t => t.length > 0);
  }

  private calculateSentiment(tokens: string[]): number {
    const positive = ['good', 'great', 'excellent', 'wonderful', 'amazing', 'love', 'happy', 'joy', 'beautiful', 'perfect'];
    const negative = ['bad', 'terrible', 'awful', 'hate', 'sad', 'angry', 'fear', 'worry', 'pain', 'hurt'];
    
    let score = 0;
    tokens.forEach(token => {
      if (positive.includes(token)) score += 0.1;
      if (negative.includes(token)) score -= 0.1;
    });
    
    return Math.max(-1, Math.min(1, score));
  }

  analyze(text: string): EmotionAnalysis {
    const tokens = this.tokenize(text);
    const emotionScores: Record<string, number> = {};
    
    // Score each emotion
    Object.entries(emotionDictionary).forEach(([emotion, data]) => {
      let score = 0;
      tokens.forEach(token => {
        if (data.words.includes(token)) {
          score += 1;
        }
      });
      emotionScores[emotion] = score;
    });
    
    // Find primary and secondary emotions
    const sorted = Object.entries(emotionScores).sort((a, b) => b[1] - a[1]);
    const primary = sorted[0][1] > 0 ? sorted[0][0] : 'neutral';
    const secondary = sorted[1] && sorted[1][1] > 0 ? sorted[1][0] : null;
    
    // Calculate intensity
    const maxScore = Math.max(...Object.values(emotionScores));
    const intensity = Math.min(0.9, 0.3 + maxScore * 0.2);
    
    // Detect concepts
    const concepts: string[] = [];
    Object.entries(conceptDictionary).forEach(([concept, words]) => {
      if (tokens.some(token => words.includes(token))) {
        concepts.push(concept);
      }
    });
    
    return {
      primary,
      secondary,
      intensity,
      concepts,
      sentiment: this.calculateSentiment(tokens)
    };
  }
}
