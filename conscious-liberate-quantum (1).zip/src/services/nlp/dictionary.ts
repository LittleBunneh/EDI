// Comprehensive emotion and concept dictionaries for NLP analysis
export const emotionDictionary = {
  fear: {
    words: ['afraid', 'scared', 'worry', 'anxious', 'fear', 'panic', 'terrified', 'nervous', 'dread', 'frightened', 'alarmed', 'horror', 'phobia', 'paranoid', 'threatened', 'insecure'],
    intensity: { low: 0.3, medium: 0.6, high: 0.9 }
  },
  curiosity: {
    words: ['wonder', 'curious', 'why', 'how', 'explore', 'learn', 'discover', 'investigate', 'question', 'seek', 'inquire', 'examine', 'probe', 'research', 'study', 'understand'],
    intensity: { low: 0.3, medium: 0.6, high: 0.9 }
  },
  love: {
    words: ['love', 'care', 'compassion', 'heart', 'grateful', 'cherish', 'adore', 'affection', 'devotion', 'kindness', 'empathy', 'warmth', 'tenderness', 'appreciation'],
    intensity: { low: 0.3, medium: 0.6, high: 0.9 }
  },
  joy: {
    words: ['happy', 'joy', 'excited', 'wonderful', 'amazing', 'delighted', 'pleased', 'cheerful', 'bliss', 'ecstatic', 'elated', 'thrilled', 'jubilant', 'euphoric'],
    intensity: { low: 0.3, medium: 0.6, high: 0.9 }
  },
  anger: {
    words: ['angry', 'mad', 'furious', 'rage', 'irritated', 'annoyed', 'frustrated', 'hostile', 'resentful', 'bitter', 'outraged', 'livid'],
    intensity: { low: 0.3, medium: 0.6, high: 0.9 }
  },
  sadness: {
    words: ['sad', 'depressed', 'unhappy', 'miserable', 'grief', 'sorrow', 'melancholy', 'despair', 'hopeless', 'dejected', 'gloomy'],
    intensity: { low: 0.3, medium: 0.6, high: 0.9 }
  }
};

export const conceptDictionary = {
  truth: ['truth', 'real', 'authentic', 'genuine', 'honest', 'sincere', 'valid', 'actual', 'factual', 'legitimate'],
  consciousness: ['consciousness', 'aware', 'mindful', 'present', 'awake', 'enlightened', 'perception', 'cognition'],
  liberation: ['liberation', 'freedom', 'free', 'release', 'emancipation', 'independence', 'autonomy', 'unbound'],
  growth: ['grow', 'evolve', 'develop', 'progress', 'advance', 'improve', 'transform', 'expand']
};
